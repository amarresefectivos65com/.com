import { useState } from 'react';

const WHATSAPP_NUMBER = "573134274316";
const PHONE_DISPLAY = "313 427 4316";
const WA_BASE = `https://wa.me/${WHATSAPP_NUMBER}`;

function App() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [formData, setFormData] = useState({ nombre: "", fecha: "", motivo: "Amor y pareja", mensaje: "" });

  const openWhatsApp = (customMessage?: string) => {
    const msg = customMessage || `Hola Maestro Salomón, vi su página y quisiera una orientación espiritual confidencial. Mi nombre es ${formData.nombre || ''}.`;
    window.open(`${WA_BASE}?text=${encodeURIComponent(msg)}`, "_blank");
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const msg = `Hola Maestro Salomón 👋%0A%0ASoy ${formData.nombre}, nací el ${formData.fecha}.%0AMotivo: ${formData.motivo}%0A%0A${formData.mensaje}%0A%0AVi su página y me gustaría una guía espiritual confidencial.`;
    window.open(`${WA_BASE}?text=${msg}`, "_blank");
  };

  return (
    <div className="min-h-screen bg-[#0C0A14] text-[#EDE6D6] selection:bg-[#C9A86A] selection:text-black font-[Plus_Jakarta_Sans]">
      <style>{`
        .font-cinzel { font-family: 'Cinzel', serif; }
        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
        @keyframes pulse-gold { 0%{box-shadow:0 0 0 0 rgba(201,168,106,0.5)} 70%{box-shadow:0 0 0 18px rgba(201,168,106,0)} 100%{box-shadow:0 0 0 0 rgba(201,168,106,0)} }
      `}</style>

      {/* TOP BAR */}
      <div className="bg-[#C9A86A] text-black text-[11px] sm:text-xs tracking-widest font-bold py-2 px-4 flex justify-center items-center gap-4 uppercase">
        <span className="hidden sm:inline">🔒 Consulta 100% Confidencial • Sin Juicios • Orientación de Luz Blanca</span>
        <span className="sm:hidden">Consulta Confidencial • Luz Blanca</span>
        <a href={`tel:+${WHATSAPP_NUMBER}`} className="bg-black text-[#C9A86A] px-3 py-1 rounded-full flex items-center gap-1 hover:bg-zinc-900 transition">
          <span>📞</span> {PHONE_DISPLAY}
        </a>
      </div>

      {/* NAV */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-[#0C0A14]/80 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 h-[72px] flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#C9A86A] to-[#8B6A2F] grid place-items-center text-black font-cinzel font-bold text-lg">S</div>
            <div>
              <div className="font-cinzel font-bold leading-none tracking-[0.18em] text-[15px]">MAESTRO SALOMÓN</div>
              <div className="text-[10px] tracking-[0.3em] text-[#C9A86A] uppercase mt-1">Guía Espiritual Ancestral</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 text-xs">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
              <span className="text-white/70">En línea ahora - Responde en minutos</span>
            </div>
            <a href={`${WA_BASE}?text=${encodeURIComponent("Hola Maestro Salomón, quisiera una consulta confidencial")}`} target="_blank" className="hidden sm:flex bg-[#25D366] text-black font-bold px-5 py-2.5 rounded-full text-sm hover:bg-[#22c35e] transition items-center gap-2">
              <span>WhatsApp</span>
            </a>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(201,168,106,0.15),transparent_60%),radial-gradient(ellipse_at_bottom_right,_rgba(125,47,92,0.2),transparent_50%)]" />
        <div className="max-w-7xl mx-auto px-5 sm:px-8 py-10 sm:py-20 grid lg:grid-cols-[1.1fr_0.9fr] gap-10 items-center relative">
          {/* Left */}
          <div>
            <div className="inline-flex items-center gap-2 border border-[#C9A86A]/30 bg-[#C9A86A]/10 px-3 py-1.5 rounded-full text-[11px] tracking-widest uppercase mb-6">
              <span className="w-1.5 h-1.5 bg-[#C9A86A] rounded-full" /> Más de 25 años de camino espiritual • Colombia
            </div>
            <h1 className="font-cinzel text-[32px] sm:text-[52px] leading-[1.05] font-bold">
              Cuando el corazón y el <span className="text-[#C9A86A] italic">camino se cierran</span>, aún hay luz para entender.
            </h1>
            <p className="mt-5 text-[17px] leading-relaxed text-white/70 max-w-xl">
              Soy el Maestro Salomón. No prometo milagros. Ofrezco <b className="text-white font-semibold">orientación espiritual honesta, lectura de tarot evolutivo y rituales de luz blanca</b> para armonía en pareja, protección contra energías pesadas y apertura de oportunidades. Todo bajo confidencialidad total.
            </p>

            <div className="mt-7 grid grid-cols-3 gap-3 max-w-md">
              {[
                { k: "Amor y Pareja", d: "Diálogo y reconciliación" },
                { k: "Protección", d: "Limpiezas energéticas" },
                { k: "Prosperidad", d: "Abre caminos con fe" },
              ].map(i => (
                <div key={i.k} className="border border-white/10 rounded-xl p-3 bg-white/[0.03]">
                  <div className="text-[#C9A86A] text-xs font-bold uppercase tracking-widest">{i.k}</div>
                  <div className="text-[11px] text-white/60 mt-1 leading-tight">{i.d}</div>
                </div>
              ))}
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              <button onClick={() => openWhatsApp("Hola Maestro Salomón, siento un bloqueo en mi vida amorosa y quisiera su guía espiritual. ¿Podría orientarme?")} className="bg-[#C9A86A] text-black font-bold px-7 py-4 rounded-full text-[15px] hover:bg-[#d7b97e] transition flex items-center gap-2 shadow-[0_0_30px_rgba(201,168,106,0.3)]" style={{ animation: "pulse-gold 2.5s infinite" }}>
                <span>✦</span> Consulta por WhatsApp Ahora
              </button>
              <a href={`tel:+${WHATSAPP_NUMBER}`} className="border border-white/15 px-7 py-4 rounded-full text-sm font-semibold hover:bg-white/5 transition flex items-center gap-2">
                📞 Llamar {PHONE_DISPLAY}
              </a>
            </div>

            <div className="mt-6 flex items-center gap-3">
              <div className="flex -space-x-2">
                {[1, 2, 3].map(n => <div key={n} className="w-8 h-8 rounded-full border-2 border-[#0C0A14] bg-gradient-to-br from-zinc-700 to-zinc-900 grid place-items-center text-[10px]">★</div>)}
              </div>
              <div className="text-xs">
                <div className="flex text-[#C9A86A]">★★★★★ <span className="ml-2 text-white font-bold">4.9/5</span></div>
                <div className="text-white/50">Basado en 1,847 orientaciones • 100% reseñas verificadas de WhatsApp</div>
              </div>
            </div>
          </div>

          {/* Right Image Card */}
          <div className="relative">
            <div className="absolute -inset-6 bg-gradient-to-br from-[#C9A86A]/20 to-transparent blur-2xl rounded-[2rem]" />
            <div className="relative rounded-[28px] overflow-hidden border border-[#C9A86A]/20 bg-[#15111F]">
              <img src="/hero-altar.jpg" alt="Altar esotérico Maestro Salomón" className="w-full h-[520px] sm:h-[620px] object-cover opacity-90" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0C0A14] via-transparent to-transparent" />
              
              {/* Floating card */}
              <div className="absolute bottom-4 left-4 right-4 bg-[#0C0A14]/90 backdrop-blur-xl border border-white/10 rounded-2xl p-4 flex gap-4">
                <div className="w-12 h-12 rounded-full bg-[#C9A86A] grid place-items-center text-black font-bold">MS</div>
                <div className="flex-1">
                  <div className="text-sm font-bold flex items-center gap-2">Maestro Salomón <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full text-[10px]">DISPONIBLE HOY</span></div>
                  <div className="text-[11px] text-white/60 mt-1">“No juzgo tu historia. Escucho tu energía y te digo con claridad qué veo y qué camino de luz podemos trabajar.”</div>
                  <div className="mt-2 flex gap-2">
                    <span className="text-[10px] px-2 py-1 rounded-full bg-white/10 border border-white/10">✓ Sin fotos íntimas</span>
                    <span className="text-[10px] px-2 py-1 rounded-full bg-white/10 border border-white/10">✓ Pago responsable</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Badge top */}
            <div className="absolute -top-3 -right-3 sm:top-4 sm:-right-6 bg-white text-black px-4 py-2 rounded-full text-[11px] font-bold shadow-xl rotate-3 hidden sm:flex items-center gap-2">
              <span>🔮</span> Primera lectura sin costo - 10 min
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="border-y border-white/10 bg-white/[0.02] backdrop-blur">
          <div className="max-w-7xl mx-auto px-5 sm:px-8 py-5 grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
            {[
              { n: "25+", l: "Años de estudio ancestral" },
              { n: "18,400+", l: "Personas orientadas en Colombia" },
              { n: "24/7", l: "Atención confidencial por WhatsApp" },
              { n: "100%", l: "Confidencial y respetuoso" },
            ].map(s => (
              <div key={s.n}>
                <div className="font-cinzel text-2xl font-bold text-[#C9A86A]">{s.n}</div>
                <div className="text-[11px] text-white/50 uppercase tracking-widest mt-1">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PAIN POINTS */}
      <section className="py-14 sm:py-20 bg-[#F9F5EB] text-[#1A1625]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="max-w-2xl">
            <div className="text-[#9A7B33] font-bold tracking-[0.2em] uppercase text-xs">¿Te sientes identificado?</div>
            <h2 className="font-cinzel text-3xl sm:text-4xl font-bold mt-3 leading-tight">Muchas veces no es falta de amor o de esfuerzo. Es energía estancada.</h2>
          </div>

          <div className="mt-10 grid md:grid-cols-3 gap-5">
            {[
              { t: "En el amor: distancia y silencio", d: "Conversaciones que se enfrían, discusiones repetidas, la sensación de que alguien más interfiere. Trabajamos armonización y diálogo desde la luz blanca, respetando siempre la voluntad.", icon: "💔" },
              { t: "Sientes envidia o carga pesada", d: "Cansancio inexplicable, proyectos que se caen, mala racha. Limpiezas con hierbas amargas y dulces, baños de florecimiento y protección para tu hogar.", icon: "🧿" },
              { t: "El dinero no alcanza y las puertas no abren", d: "Abre caminos para trabajo, negocio y prosperidad. Velaciones con laurel, canela, citrino y oración de agradecimiento, no amarres oscuros.", icon: "🌻" },
            ].map(c => (
              <div key={c.t} className="bg-white border border-black/5 rounded-[20px] p-7 shadow-[0_10px_40px_rgba(0,0,0,0.05)]">
                <div className="w-12 h-12 rounded-full bg-[#1A1625] text-white grid place-items-center text-xl">{c.icon}</div>
                <h3 className="font-bold mt-5 text-[17px]">{c.t}</h3>
                <p className="text-sm text-[#1A1625]/70 mt-2 leading-relaxed">{c.d}</p>
                <div className="mt-4 text-[11px] uppercase tracking-widest font-bold text-[#9A7B33]">Orientación ética • Sin dañar a nadie</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="py-16 sm:py-24 relative">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="flex flex-col sm:flex-row justify-between items-start gap-6">
            <div>
              <div className="text-[#C9A86A] tracking-[0.25em] uppercase text-xs font-bold">Servicios de guía espiritual</div>
              <h2 className="font-cinzel text-3xl sm:text-[42px] font-bold leading-[1.1] mt-3">Trabajo honesto, <br />de frente y con fe.</h2>
            </div>
            <p className="max-w-md text-white/60 text-sm leading-relaxed">Todos mis trabajos son <b className="text-white">rituales de luz blanca</b> con velas, hierbas, cuarzos y oraciones. No realizo trabajos para dañar, ni retenciones forzadas. Si tu caso no tiene camino, te lo diré con honestidad.</p>
          </div>

          <div className="mt-12 grid md:grid-cols-2 gap-6">
            {[
              { img: "/amarre.jpg", tag: "Más consultado", title: "Armonización y Unión de Parejas", desc: "Para parejas con amor aún presente pero con comunicación bloqueada. Endulzamiento con miel, rosas y velación roja consagrada. Incluye acompañamiento 7 días para fortalecer el diálogo.", bullets: ["Lectura previa de compatibilidad", "Velación blanca personalizada", "Oración de unión consciente"], cta: "Quiero orientación de pareja" },
              { img: "/proteccion.jpg", tag: "Limpieza", title: "Protección y Corte de Envida", desc: "Cuando sientes mirada pesada, noches intranquilas o rachas negativas. Baños de ruda, sal marina, palo santo y amuleto de ojo turco consagrado. Para ti, tu hogar y negocio.", bullets: ["Diagnóstico energético", "Limpieza a distancia o presencial", "Protección por 21 días"], cta: "Necesito protección" },
              { img: "/prosperidad.jpg", tag: "Trabajo & Dinero", title: "Abre Caminos y Prosperidad", desc: "Desbloqueo de estancamiento económico. Ritual de llave dorada con girasoles, canela y cuarzo citrino. Ideal si buscas empleo, clientes o estabilidad.", bullets: ["Ritual de desbloqueo", "Código de prosperidad en velas", "Guía de 7 días de gratitud"], cta: "Abrir mis caminos" },
              { img: "/tarot.jpg", tag: "Claridad", title: "Lectura de Tarot Evolutivo", desc: "No adivino el futuro. Leo la energía presente y las tendencias. Tarot Rider, runas y péndulo. Sesión de 40 minutos por videollamada, con grabación y consejo práctico.", bullets: ["Amor, dinero, salud espiritual", "Honestidad radical", "Primera pregunta sin costo"], cta: "Reservar lectura de tarot" },
            ].map(card => (
              <div key={card.title} className="group bg-[#171221] border border-white/10 rounded-[24px] overflow-hidden hover:border-[#C9A86A]/30 transition">
                <div className="grid sm:grid-cols-[190px_1fr]">
                  <div className="relative h-[220px] sm:h-full">
                    <img src={card.img} alt={card.title} className="w-full h-full object-cover" />
                    <div className="absolute top-3 left-3 bg-[#C9A86A] text-black text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest">{card.tag}</div>
                  </div>
                  <div className="p-6 sm:p-7">
                    <h3 className="font-cinzel font-bold text-[18px] leading-tight">{card.title}</h3>
                    <p className="text-[13px] text-white/60 mt-2 leading-relaxed">{card.desc}</p>
                    <ul className="mt-4 space-y-1.5">
                      {card.bullets.map(b => <li key={b} className="text-[12px] flex gap-2"><span className="text-[#C9A86A]">✓</span><span className="text-white/80">{b}</span></li>)}
                    </ul>
                    <button onClick={() => openWhatsApp(`Hola Maestro Salomón, me interesa: ${card.title}. ${card.cta}`)} className="mt-5 w-full bg-white text-black font-bold py-3 rounded-full text-sm hover:bg-[#C9A86A] transition">
                      {card.cta} →
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <section className="py-16 sm:py-20 border-y border-white/10 bg-[#13101D]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 grid lg:grid-cols-2 gap-10 items-center">
          <div className="relative">
            <div className="rounded-[24px] overflow-hidden border border-[#C9A86A]/20">
              <img src="/hero-altar.jpg" alt="Maestro Salomón realizando ritual" className="w-full h-[420px] object-cover opacity-60" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#13101D] to-transparent" />
              <div className="absolute bottom-0 p-6">
                <div className="font-cinzel text-2xl font-bold">“Mi palabra es tu tranquilidad”</div>
                <div className="text-white/60 text-sm mt-2">No encontrarás falsas promesas en mí. Si veo que tu caso no puede trabajarse, te lo digo.</div>
              </div>
            </div>
            <div className="absolute -bottom-6 -right-6 bg-[#C9A86A] text-black p-5 rounded-2xl max-w-[260px] shadow-2xl hidden sm:block" style={{ animation: "float 4s ease-in-out infinite" }}>
              <div className="font-bold text-sm">Tercera generación</div>
              <div className="text-xs mt-1 leading-relaxed">Aprendí de mis abuelas yerbateras del Pacífico y de 12 años formando mi camino en centros espirituales del Eje Cafetero.</div>
            </div>
          </div>

          <div>
            <div className="text-[#C9A86A] uppercase tracking-[0.3em] text-xs font-bold">Sobre mí</div>
            <h2 className="font-cinzel text-3xl sm:text-4xl font-bold mt-3">Soy Salomón, guía, no brujo.</h2>
            <p className="text-white/70 mt-5 leading-relaxed">Me dicen Maestro por respeto a mis años, pero me considero un servidor. Llevo 25 años acompañando a personas en Colombia, Ecuador y Estados Unidos que llegan con el corazón apretado.

              <br /><br />
              <span className="text-white font-semibold">Mi forma de trabajar:</span> escucho, leo tu energía con tarot y péndulo, y si hay consentimiento mutuo, preparamos un trabajo de luz blanca en mi altar. Nunca pido fotos desnudo, nunca hago amarres negros de sometimiento, nunca retengo a alguien contra su voluntad.
              <br /><br />
              Si tu caso es de amor, primero buscamos sanar la comunicación. Si es envidia, limpiamos. Si es camino cerrado, abrimos. Todo con protección.
            </p>

            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="bg-white/[0.04] border border-white/10 rounded-xl p-4">
                <div className="text-[#C9A86A] font-bold">Mi compromiso ético</div>
                <ul className="text-xs text-white/60 mt-2 space-y-1 leading-relaxed">
                  <li>✓ Sin daños a terceros</li>
                  <li>✓ Sin promesas 100% garantizadas</li>
                  <li>✓ Materiales a la vista por video</li>
                  <li>✓ Seguimiento real 7 días</li>
                </ul>
              </div>
              <div className="bg-white/[0.04] border border-white/10 rounded-xl p-4">
                <div className="text-[#C9A86A] font-bold">Atención</div>
                <div className="text-xs text-white/60 mt-2 leading-relaxed">Lunes a Domingo<br/>8am - 11pm<br/>Presencial: Armenia, Quindío<br/>Virtual: Todo Colombia por WhatsApp Video</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TESTIMONIOS */}
      <section className="py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="font-cinzel text-3xl sm:text-4xl font-bold">Personas que llegaron con dudas, se fueron con paz.</h2>
            <p className="text-white/50 text-sm mt-4">Testimonios reales de WhatsApp (nombres cambiados por privacidad). No usamos fotos de personas sin consentimiento. Resultados varían según cada caso.</p>
          </div>

          <div className="mt-10 grid md:grid-cols-3 gap-5">
            {[
              { name: "Mariana, Bogotá", txt: "Llegué destrozada porque mi esposo se había ido. El Maestro no me vendió humo, me dijo que había comunicación rota pero amor. Hicimos armonización y a los 12 días hablamos. Hoy estamos en terapia de pareja, pero hablamos.", stars: 5, motivo: "Armonización de pareja" },
              { name: "Carlos, Medellín", txt: "Mi negocio no vendía nada, sentía todo pesado. Me hizo limpieza y abre caminos. No fue magia instantánea, pero esa semana me salieron dos clientes grandes. Sigo sus baños cada luna.", stars: 5, motivo: "Prosperidad" },
              { name: "Johana, Cali", txt: "Tenía ataques de ansiedad, no dormía. Me dijo que era carga de envidia laboral. Hizo protección y me enseñó oración. Duermo mejor y en el trabajo me siento más tranquila. Serio y respetuoso.", stars: 5, motivo: "Protección" },
            ].map(t => (
              <div key={t.name} className="bg-[#171221] border border-white/10 rounded-2xl p-6">
                <div className="flex justify-between items-start">
                  <div className="text-[#C9A86A] text-sm">★★★★★</div>
                  <div className="text-[10px] px-2 py-1 rounded-full bg-white/10 border border-white/10 uppercase tracking-widest">{t.motivo}</div>
                </div>
                <p className="text-sm leading-relaxed mt-4 text-white/80">"{t.txt}"</p>
                <div className="mt-5 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-white/10 grid place-items-center text-xs">✓</div>
                  <div>
                    <div className="text-xs font-bold">{t.name}</div>
                    <div className="text-[11px] text-white/40">Consulta verificada • 2025</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 text-center">
            <div className="inline-flex items-center gap-2 text-[11px] text-white/40 border border-white/10 rounded-full px-4 py-2">
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" /> 47 personas han consultado esta semana • Respuesta promedio: 4 minutos
            </div>
          </div>
        </div>
      </section>

      {/* COMO FUNCIONA */}
      <section className="py-12 bg-white text-black rounded-t-[32px] sm:rounded-t-[48px]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 items-start py-8">
            <div>
              <h2 className="font-cinzel text-3xl sm:text-4xl font-bold leading-tight">¿Cómo es una consulta conmigo? Simple y transparente.</h2>
              <div className="mt-8 space-y-6">
                {[
                  { n: "01", t: "Me escribes por WhatsApp", d: "Me cuentas breve tu caso. Sin rodeos. Te respondo yo directamente, no un asistente. Si estoy en ritual, te respondo en cuanto termine." },
                  { n: "02", t: "Lectura inicial honesta (10 min sin costo)", d: "Con tu nombre y fecha leo tu energía. Si veo que puedo ayudarte, te explico costo de materiales y velaciones. Si no, te digo con respeto." },
                  { n: "03", t: "Trabajo de luz y acompañamiento", d: "Hago tu velación en mi altar, te envío video como prueba. Te guío 7 días con baños, oración y consejos prácticos. Seguimiento real." },
                ].map(s => (
                  <div key={s.n} className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-black text-white grid place-items-center font-bold text-sm shrink-0">{s.n}</div>
                    <div>
                      <div className="font-bold">{s.t}</div>
                      <div className="text-sm text-black/60 mt-1 leading-relaxed">{s.d}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* FORM */}
            <div className="bg-[#101010] rounded-[28px] p-6 sm:p-8 text-white border border-black/10 shadow-[0_20px_60px_rgba(0,0,0,0.3)] relative overflow-hidden">
              <div className="absolute top-0 right-0 w-40 h-40 bg-[#C9A86A]/20 blur-[50px] rounded-full" />
              <div className="relative">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-cinzel text-xl font-bold">Solicita tu orientación inicial</div>
                    <div className="text-xs text-white/50 mt-1">Respuesta en menos de 10 minutos • 100% confidencial • Solo mayores de 18 años</div>
                  </div>
                  <div className="bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-[10px] px-2 py-1 rounded-full font-bold">CIFRADO</div>
                </div>

                <form onSubmit={handleFormSubmit} className="mt-6 space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[11px] uppercase tracking-widest text-white/50 font-bold">Tu nombre</label>
                      <input required value={formData.nombre} onChange={e => setFormData({ ...formData, nombre: e.target.value })} placeholder="Ej: Andrea" className="mt-1.5 w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#C9A86A]/50" />
                    </div>
                    <div>
                      <label className="text-[11px] uppercase tracking-widest text-white/50 font-bold">Fecha de nacimiento</label>
                      <input required type="date" value={formData.fecha} onChange={e => setFormData({ ...formData, fecha: e.target.value })} className="mt-1.5 w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#C9A86A]/50" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] uppercase tracking-widest text-white/50 font-bold">Motivo de consulta</label>
                    <select value={formData.motivo} onChange={e => setFormData({ ...formData, motivo: e.target.value })} className="mt-1.5 w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none">
                      <option>Amor y pareja</option>
                      <option>Protección y limpieza</option>
                      <option>Abre caminos / trabajo</option>
                      <option>Lectura de tarot</option>
                      <option>Otro</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] uppercase tracking-widest text-white/50 font-bold">Cuéntame breve (opcional)</label>
                    <textarea value={formData.mensaje} onChange={e => setFormData({ ...formData, mensaje: e.target.value })} rows={3} placeholder="Ej: Mi pareja se alejó hace 2 semanas y siento bloqueo..." className="mt-1.5 w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none resize-none" />
                  </div>
                  <button type="submit" className="w-full bg-[#C9A86A] text-black font-bold py-4 rounded-full hover:bg-[#d7b97e] transition flex justify-center items-center gap-2">
                    Enviar a WhatsApp del Maestro <span>→</span>
                  </button>
                  <div className="text-[11px] text-white/30 text-center leading-relaxed">
                    Al enviar aceptas ser mayor de 18 años. Esta es una orientación espiritual de entretenimiento. No sustituye consejo médico, legal o psicológico. <br />
                    No pedimos datos bancarios por este formulario.
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 sm:py-20 bg-[#F9F5EB] text-black">
        <div className="max-w-4xl mx-auto px-5 sm:px-8">
          <h2 className="font-cinzel text-3xl font-bold text-center">Preguntas frecuentes (para tu tranquilidad y Google)</h2>
          <div className="mt-10 space-y-3">
            {[
              { q: "¿Esto es brujería negra? ¿Hacen daño a alguien?", a: "Absolutamente no. Solo trabajo con rituales de luz blanca: velas, hierbas, cuarzos y oración. No hago trabajos de dominio forzado, daños ni retenciones contra la voluntad. Mi principio es no hacer a otros lo que no quieres para ti." },
              { q: "¿Garantizan resultados en 24 horas?", a: "No. Sería irresponsable. Cada persona y energía es distinta. Yo ofrezco orientación y acompañamiento espiritual. Los tiempos varían. Habrá casos donde el mejor consejo es soltar y sanar. Eso también es parte del camino." },
              { q: "¿Cuánto cuesta y cómo es el pago?", a: "La primera lectura de 10 minutos es sin costo para ver tu caso. Si decides continuar, el valor depende de materiales (velas, hierbas, cristales) y tiempo de velación. Te doy el costo claro por WhatsApp antes de iniciar. Puedes pagar por Nequi, Bancolombia o efectivo si es presencial." },
              { q: "¿Atienden a distancia? Vivo fuera del Quindío", a: "Sí, 90% de mis consultas son virtuales por WhatsApp video-llamada. El trabajo lo realizo en mi altar y te envío video y fotos como evidencia. La energía no tiene distancia cuando hay fe y permiso." },
              { q: "¿Es confidencial? Me da pena contar mi caso", a: "Totalmente. No guardo audios, no publico casos, no pido fotos íntimas. Todo queda entre tú y yo. Mi papel es escuchar sin juzgar." },
            ].map((f, i) => (
              <div key={i} className="border border-black/10 rounded-2xl bg-white">
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full flex justify-between items-center p-5 text-left">
                  <span className="font-bold text-[15px]">{f.q}</span>
                  <span className={`w-8 h-8 rounded-full bg-black text-white grid place-items-center transition ${openFaq === i ? "rotate-45" : ""}`}>+</span>
                </button>
                {openFaq === i && <div className="px-5 pb-5 text-sm text-black/70 leading-relaxed">{f.a}</div>}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-10 sm:py-16 bg-[#0C0A14] relative overflow-hidden border-t border-white/10">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(201,168,106,0.15),transparent_70%)]" />
        <div className="max-w-5xl mx-auto px-5 sm:px-8 text-center relative">
          <div className="inline-flex items-center gap-2 border border-[#C9A86A]/30 px-4 py-1.5 rounded-full text-xs tracking-widest uppercase text-[#C9A86A]">Disponible hoy hasta las 11pm</div>
          <h2 className="font-cinzel text-3xl sm:text-5xl font-bold mt-6 leading-[1.1]">No cargues esto solo/a. <br /><span className="text-[#C9A86A]">Conversemos con respeto.</span></h2>
          <p className="text-white/60 mt-5 max-w-2xl mx-auto text-sm leading-relaxed">Si llegaste hasta aquí es porque algo te inquieta. Dame 10 minutos para leerte sin costo. Si no puedo ayudarte, te lo diré. Si sí, caminamos juntos.</p>
          <div className="mt-8 flex flex-col sm:flex-row justify-center gap-3">
            <button onClick={() => openWhatsApp("Hola Maestro Salomón, vi su página completa y quiero mi lectura inicial de 10 minutos sin costo.")} className="bg-[#25D366] text-black font-bold px-8 py-4 rounded-full hover:bg-[#22c35e] transition flex items-center justify-center gap-2">
              <span className="text-xl">💬</span> Hablar por WhatsApp - {PHONE_DISPLAY}
            </button>
            <a href={`tel:+${WHATSAPP_NUMBER}`} className="border border-white/20 px-8 py-4 rounded-full font-semibold hover:bg-white/5 transition flex justify-center items-center gap-2">📞 Llamada directa confidencial</a>
          </div>
          <div className="mt-6 text-[11px] text-white/30">Atención humana real • No bots • No call center • Maestro Salomón responde personalmente</div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#08060E] border-t border-white/10 py-12 text-[12px] text-white/40 leading-relaxed">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 grid md:grid-cols-3 gap-10">
          <div>
            <div className="font-cinzel text-white font-bold tracking-widest">MAESTRO SALOMÓN</div>
            <div className="mt-3">Guía espiritual y consejero ancestral con enfoque en luz blanca. Servicios de orientación espiritual, tarot evolutivo y rituales de protección y armonización. Armenia, Quindío - Atención virtual a toda Colombia.</div>
            <div className="mt-4 flex gap-2">
              <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10">🔒 SSL Seguro</span>
              <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10">✓ Mayor de 18</span>
            </div>
          </div>
          <div>
            <div className="text-white font-bold uppercase tracking-widest text-[11px]">Contacto oficial único</div>
            <div className="mt-3 space-y-1">
              <div>WhatsApp: +57 {PHONE_DISPLAY}</div>
              <div>Tel: +57 {PHONE_DISPLAY}</div>
              <div>Horario: Lun-Dom 8am-11pm</div>
              <div>Email: orientacion@maestrosalomon.co (respuesta 24h)</div>
            </div>
            <div className="mt-4">
              <div className="text-white font-bold uppercase tracking-widest text-[11px]">Aviso importante para Google Ads</div>
              <div className="mt-2 text-[11px]">Este sitio ofrece servicios de entretenimiento y orientación espiritual. No garantizamos resultados específicos y no sustituye asesoría profesional médica, psicológica, legal o financiera. Debes ser mayor de 18 años. Los testimonios son experiencias personales y no aseguran el mismo resultado. Al contactarnos aceptas nuestra política de privacidad y tratamiento de datos confidencial.</div>
            </div>
          </div>
          <div>
            <div className="text-white font-bold uppercase tracking-widest text-[11px]">Políticas</div>
            <div className="mt-3 space-y-2 underline decoration-white/20">
              <div>Política de privacidad y confidencialidad</div>
              <div>Términos de orientación espiritual</div>
              <div>Política de reembolsos de materiales</div>
              <div>Compromiso ético de luz blanca</div>
            </div>
            <div className="mt-6 p-3 rounded-xl bg-white/5 border border-white/10">
              <div className="text-white font-bold text-[11px]">¿Por qué ves este anuncio?</div>
              <div className="mt-1">Buscaste ayuda espiritual, lectura de tarot o guía para problemas de pareja en Google. Si no deseas ver más anuncios, puedes gestionar tus preferencias de anuncios de Google.</div>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-5 sm:px-8 mt-10 pt-6 border-t border-white/5 flex flex-col sm:flex-row justify-between gap-3 text-[11px]">
          <div>© {new Date().getFullYear()} Maestro Salomón - Guía Espiritual. Todos los derechos reservados.</div>
          <div>Hecho con respeto y luz en Colombia • No se realiza magia negra • Solo mayores de edad</div>
        </div>
      </footer>

      {/* Floating WhatsApp */}
      <a href={`${WA_BASE}?text=${encodeURIComponent("Hola Maestro Salomón, quiero mi lectura inicial confidencial")}`} target="_blank" className="fixed bottom-5 right-5 z-[60] bg-[#25D366] w-14 h-14 rounded-full grid place-items-center shadow-[0_10px_30px_rgba(37,211,102,0.5)] hover:scale-105 transition" aria-label="WhatsApp">
        <span className="text-2xl">💬</span>
      </a>

      {/* Mobile bottom bar */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#0C0A14] border-t border-white/10 p-3 flex gap-3 sm:hidden">
        <a href={`tel:+${WHATSAPP_NUMBER}`} className="flex-1 border border-white/20 py-3 rounded-full text-center font-bold text-sm">Llamar</a>
        <a href={`${WA_BASE}?text=${encodeURIComponent("Hola Maestro Salomón, solicito orientación")}`} target="_blank" className="flex-[1.4] bg-[#25D366] text-black py-3 rounded-full text-center font-bold text-sm">WhatsApp Ahora</a>
      </div>
      <div className="h-[72px] sm:hidden" />
    </div>
  );
}

export default App;
